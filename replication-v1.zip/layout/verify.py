"""Independently recompute the primary predictions using the Python standard library."""
import csv
import gzip
import hashlib
import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    expected = json.loads((ROOT / "results.json").read_text())
    for filename, checksum in expected["inputs_sha256"].items():
        if hashlib.sha256((ROOT / filename).read_bytes()).hexdigest() != checksum:
            raise ValueError(f"Input file changed: {filename}")
    with gzip.open(ROOT / "strip-edges.json.gz", "rt", encoding="utf-8") as f:
        puzzles = json.load(f)
    keys = json.loads((ROOT / "strip-key.json").read_text())
    with (ROOT / "predictions.csv").open(encoding="utf-8") as f:
        recorded = {r["image"]: r for r in csv.DictReader(f) if r["condition"] == "all_marks"}
    assert set(puzzles) == set(recorded) == set(keys)
    exact, matched = 0, 0
    for scan, bands in puzzles.items():
        distance = {}
        for a, b in itertools.permutations(range(len(bands)), 2):
            distance[a, b] = math.fsum(
                abs(math.sqrt(v) - math.sqrt(w))
                for ca, cb in zip(bands[a][1], bands[b][0])
                for v, w in zip(ca, cb)
            )
        candidates = itertools.permutations(range(len(bands)))
        best = min(candidates, key=lambda order: sum(distance[p] for p in zip(order, order[1:])))
        guess = "".join("ABCD"[i] for i in best)
        if guess != recorded[scan]["predicted_order"]:
            raise ValueError(scan)
        actual = keys[scan]["order"]
        exact += list(best) == actual
        matched += sum((a, b) in set(zip(actual, actual[1:])) for a, b in zip(best, best[1:]))
    metrics = expected["conditions"]["all_marks"]
    assert exact == metrics["exact"] and matched == metrics["joins"]
    print(f"{len(puzzles)} primary predictions independently recomputed. {exact} full orders and {matched} joins matched.")


if __name__ == "__main__":
    main()
