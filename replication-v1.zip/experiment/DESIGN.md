# Where does this fragment belong?

Design written on 25 November 2026 before running this particular comparison on manuscript words. This is an exploratory reconstruction exercise on a transcription used in earlier project research.

Each puzzle shows two upper fragments and two lower fragments from two pages. Join them into two pages using only token forms. With two possible complete assemblies, chance accuracy is 50%. Anonymize the input and write the answer key separately. The decoder receives only token strings for four anonymous fragments. No vocabulary, parameters or examples are learned from elsewhere in the manuscript.

## Cutting the pieces

Use Zandbergen–Landini ZL3b normalized EVA, source SHA-256 `bf5b6d4ac1e3a51b1847a9c388318d609020441ccd56984c901c32b09beccafc`. Restrict to unnumbered-panel, simple recto/verso page identifiers with recorded quire, physical sheet within quire, hand, illustration class and Currier class. Use P0 running text only. Drop the first and last P0 lines of each page and the first and last transcribed words of every remaining line. Resolve bracket alternatives to their first reading, split uncertain spaces, and retain only tokens made entirely of lower-case Latin letters after the project's standard transcription markup cleanup. These are editorial tokens and letter strings.

Take the first and last 12 eligible words on different rows with at least one whole P0 row between the two pieces. Keep source locus and original token ordinal for audit. Opposing fragments are on different sheets. Pair sheets only inside the same quire, then pair pages within these sheets only where illustration class, recorded hand and Currier class are identical. Within each shared class pair the first eligible page on each sheet, then the second, etc., in folio-number, recto/verso order. Choose the disjoint sheet pairing that maximizes the total number of page puzzles in that quire (lexical sheet-order tiebreak). No sheet appears in two sheet pairs. Eligibility and pairing can see the metadata and the available token counts, never token identities or matching scores.

## Scoring

The primary decoder compares frequency vectors of exact token spellings using cosine similarity and chooses the assembly with the larger sum of the two similarities. Report wins, ties, losses, and accuracy counting a tie as half. Preselected diagnostics use the same rule on token lengths alone and on within-token three-letter sequences with boundary sentinels. The scorer may ignore token order. The latter two decoders are descriptive comparisons.

Preserve correlations by flipping the correct assembly direction for all puzzles in a sheet pair together to obtain the one-sided randomization tail for being above chance. Report a second, coarser sign-flip tail at whole-quire level. In both, identical signs across the cluster are flipped as a unit and the statistic is overall puzzle accuracy. Evaluate a second null by randomly repartitioning each puzzle's 48 words into four equal fragments, independently by puzzle, 999 times with a fixed seed. A planted fixture with paired disjoint repeated words must resolve both possible key orientations; four identical fragments must tie.

This measures the recoverability of pieces from known, surviving pages at one fragment size. It does not reconstruct a missing page, infer historical ordering or identify meanings. The project's label-to-body retrieval tests and prior page-level vocabulary findings motivate this distinct running-text-to-running-text task. All manuscript text has prior project exposure. No sealed scoring, visual annotations or semantic claim enters this exercise.
