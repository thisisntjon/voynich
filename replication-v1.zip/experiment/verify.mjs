// Derive all assignments from the anonymous packet, then open the saved outcomes.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = process.argv[2] ?? fileURLToPath(new URL('.', import.meta.url));
const read = name => JSON.parse(readFileSync(join(dir, name), 'utf8'));
const puzzles = read('puzzles.json');
const methods = ['spelling', 'length', 'trigrams'];

function normalizedVector(words, method) {
  const bag = new Map();
  for (const word of words) {
    const padded = '^' + word + '$';
    let features = [word];
    if (method === 'length') features = [word.length];
    if (method === 'trigrams') features = Array.from(word, (_, i) => padded.slice(i, i + 3));
    for (const f of features) bag.set(f, (bag.get(f) ?? 0) + 1);
  }
  const norm = Math.hypot(...bag.values());
  for (const [f, v] of bag) bag.set(f, v / norm);
  return bag;
}

function difference(a, b) {
  const result = new Map(a);
  for (const [f, v] of b) result.set(f, (result.get(f) ?? 0) - v);
  return result;
}

// (top A – top B) dot (bottom A – bottom B) tests the two complete assemblies.
function solve(puzzle, method) {
  const compare = part => difference(...puzzle[part].map(words => normalizedVector(words, method)));
  const top = compare('top');
  const bottom = compare('bottom');
  let advantage = 0;
  for (const [f, v] of top) advantage += v * (bottom.get(f) ?? 0);
  return Math.abs(advantage) < 1e-12 ? 0 : Math.sign(advantage);
}

const predictions = puzzles.map(p => Object.fromEntries([
  ['puzzle', p.puzzle], ...methods.map(m => [m, solve(p, m)]),
]));
assert.deepEqual(predictions, read('predictions.json'));
const key = read('answer_key.json');
const summary = read('results.json');
const seenPages = new Set();
const sheetPartners = new Map();
const counts = Object.fromEntries(methods.map(m => [m, { wins: 0, losses: 0, ties: 0 }]));
for (const [i, pred] of predictions.entries()) {
  const truth = key[pred.puzzle];
  const origins = truth.origins;
  for (const part of ['top', 'bottom']) {
    for (const j of [0, 1]) {
      const indices = origins[part][j].words;
      assert.equal(puzzles[i][part][j].length, 12);
      assert.equal(new Set(indices).size, 12);
    }
  }
  const [p, q] = origins.top.map(v => v.surface);
  assert(p !== q && !seenPages.has(p) && !seenPages.has(q));
  seenPages.add(p); seenPages.add(q);
  assert.deepEqual(origins.bottom.map(v => v.surface).sort(), [p, q].sort());
  assert.equal(truth.orientation, p === origins.bottom[0].surface ? 1 : -1);
  const [a, b] = truth.sheets.split('/');
  assert(a !== b);
  for (const [x, y] of [[a, b], [b, a]]) {
    assert.equal(sheetPartners.get(x) ?? y, y);
    sheetPartners.set(x, y);
  }
  for (const m of methods) {
    const sign = pred[m] * truth.orientation;
    counts[m][({ '-1': 'losses', '0': 'ties', '1': 'wins' })[sign]]++;
  }
}
for (const m of methods) {
  for (const [field, n] of Object.entries(counts[m])) assert.equal(summary.results[m][field], n);
}
assert.equal(summary.paired_surfaces, seenPages.size);
assert.equal(summary.disjoint_sheet_pairs, sheetPartners.size / 2);
console.log(JSON.stringify({ puzzles: puzzles.length, assignmentsChecked: 3 * puzzles.length,
  pairedSurfaces: seenPages.size, sheetPairs: sheetPartners.size / 2, counts }));
