Voynich Reconstruction Atlas 1.0.0
From the extracted folder run:
  python layout/verify.py
  node experiment/verify.mjs
Python 3 standard library and Node.js 18+ are sufficient; neither command needs network access.
Expected: 168 primary layout predictions verified, 82 exact pages, 354 correct joins.
Expected: 183 decoder choices checked on 61 puzzles built from 122 surfaces.
The sealed answer key here belongs only to these already reported, completed exercises.
The four-choice follow-up provides observed placements and all comparison rows in retrieval/.
Its quartets overlap. Weight each surface equally to reproduce reported individual accuracy.
The four-choice data are for analysis; the two commands above verify the first two experiments only.
